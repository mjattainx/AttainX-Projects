import { CognitoUserPool } from 'amazon-cognito-identity-js'

const poolData = {
    UserPoolId : "us-east-1_oelWoJYCs",
    ClientId: "57baeqcv660lro7uhbn96lctjj"
}