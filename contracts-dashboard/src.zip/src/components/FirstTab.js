import React from 'react'

const FirstTab = () => {
    return (
        <div style = {{marginTop: '30px'}}>
            <p>
                First Tab Goes here
            </p>
            <p>
                The authorization status of this account is Admin.
            </p>
            <p>
                Admin content goes here
            </p>

        </div>
    )
}

export default FirstTab
