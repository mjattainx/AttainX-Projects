import React from 'react'

const UserTab = () => {
    return (
        <div style = {{marginTop: '30px'}}>
            <p>
            The authorization status of this account is User.
            </p>
            <p>
                User Tab Goes here
            </p>

        </div>
    )
}

export default UserTab
