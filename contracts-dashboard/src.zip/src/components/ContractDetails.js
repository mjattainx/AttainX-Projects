import React from 'react'
import axios from 'axios'
import { withRouter } from 'react-router-dom'


function ContractDetails(props) {
    var str = props.match.params.id

    return (
        <div>
            yes
        </div>
    )
}

export default withRouter(ContractDetails)
