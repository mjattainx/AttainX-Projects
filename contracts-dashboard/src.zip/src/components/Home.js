import React, { useState } from 'react';
import { Tab } from 'semantic-ui-react';
import '../App.scss';
import FirstTab from './FirstTab';
import SecondTab from './SecondTab';
import ThirdTab from './ThirdTab';
import JqueryTab from './JqueryTab';
// import EmployeeTable from './EmployeeTableObselete';
import UserTab from './UserTab';
import AddEmployee from './AddEmployee';
import EmployeeTable from './EmployeeTable';
import EmployeeTab from './EmployeeTab'
import EditableContractTable from './EditableContractTable'
import EditableEmployeeTable from './EditableEmployeeTable';
import Debug from './Debug'

import { Auth } from 'aws-amplify';

const panesAdmin = [
	{ menuItem: 'Admin', render: () => 
		<Tab.Pane attached='top'>
			<FirstTab/>
		</Tab.Pane> },
	// { menuItem: 'Contract Table right click', render: () => 
	// 	<Tab.Pane attached='top'>
	// 		<SecondTab/>
	// 	</Tab.Pane> },
	// { menuItem: 'Employee Table', render: () => 
	// 	<Tab.Pane attached='top'>
	// 		<div style = {{marginTop: '27px'}}>
	// 			<EmployeeTable/>
	// 		</div>
	// 	</Tab.Pane> },
	// { menuItem: 'Add Employee', render: () => 
	// 	<Tab.Pane attached='top'>
	// 		<div style = {{marginTop: '27px'}}>
	// 			<AddEmployee/>
	// 		</div>
	// 	</Tab.Pane> },
	{ menuItem: 'Employee Table', render: () => 
		<Tab.Pane attached='top'>
			<div style = {{marginTop: '27px'}}>
				<EmployeeTab/>
			</div>
		</Tab.Pane> },
	{ menuItem: 'Contract Table', render: () => 
		<Tab.Pane attached='top'>
			<div style = {{marginTop: '27px'}}>
				{/* <JqueryTab/> */}
				<ThirdTab/>
			</div>
		</Tab.Pane> },
	// { menuItem: 'Add Contract', render: () => 
	// 	<Tab.Pane attached='top'>
	// 		<ThirdTab />
	// 	</Tab.Pane> },
	{ menuItem: 'Editable Contract Table', render: () => 
		<Tab.Pane attached='top'>
			<div style = {{marginTop: '30px'}}>
				<EditableContractTable />
			</div>
		</Tab.Pane> },
	{ menuItem: 'Editable Employee Table', render: () => 
		<Tab.Pane attached='top'>
			<div style = {{marginTop: '30px'}}>
				<EditableEmployeeTable />
			</div>
		</Tab.Pane> },
	{ menuItem: 'debug tab', render: () => 
		<Tab.Pane attached='top'>
			<div style = {{marginTop: '30px'}}>
				<Debug />
			</div>
		</Tab.Pane> },
]

const panesUser = [
	{ menuItem: 'User', render: () => 
	<Tab.Pane attached='top'>
		<UserTab/>
	</Tab.Pane> },
	{ menuItem: 'Contract Table', render: () => 
		<Tab.Pane attached='top'>
			<div style = {{marginTop: '30px'}}>
				<JqueryTab/>
			</div>
		</Tab.Pane> }
]


const Home = (props) => {
	// const debug = () => {
	// 	console.log(props.auth.authLevel)
	// }
	if (props.auth.authLevel === 'Admin') {
		return(
			
			<div>

				{/* <button onClick = {debug} > debug </button> */}
				{/* <button onClick = {getSession} > get cognito session</button> */}
				<Tab menu={{ attached: false }} panes={panesAdmin} />
			</div>
		)
	}

	if (props.auth.authLevel === 'User') {
		return(
			<div>
				<Tab menu={{ attached: false }} panes={panesUser} />
			</div>
		)
	}

	

	return (
		<div>
			Loading...
		</div>
	)

} 

export default Home;
