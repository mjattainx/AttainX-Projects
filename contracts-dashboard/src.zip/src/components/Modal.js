import axios from "axios";
import React, { useState } from "react";
import "./Modal.css";
import { Button } from 'semantic-ui-react';



export default function Modal(props) {
  const [modal, setModal] = useState(false);

  const toggleModal = () => {
    setModal(!modal);
  };

  const debug = () => {
    if (document.getElementById('start').valueAsDate !== null) {
      var date = document.getElementById('start').valueAsDate.toISOString().slice(0,10)
      date = date.split('-')
      var date = date[1] + '-' + date[2] + '-' + date[0]
      console.log(date)
    } else {
      console.log("it's null")
    }

    // console.log("start is ," , start.toString(), "end is ," ,end)
  }

  const submit = async () => {
    if (document.getElementById('start').valueAsDate !== null) {
      var start = document.getElementById('start').valueAsDate.toISOString().slice(0,10)
      start = start.split('-')
      start = start[1] + '-' + start[2] + '-' + start[0] 
    }
    if (document.getElementById('end').valueAsDate !== null) {
      var end = document.getElementById('end').valueAsDate.toISOString().slice(0,10)
      end = end.split('-')
      end = end[1] + '-' + end[2] + '-' + end[0] 
    }
    var newData = props.newData
      newData["employee id"].push({
          // "emp start date": props.rowData["emp start date"],
          "emp start date": start,
          "emp work email": props.rowData["emp work email"],
          "emp personal email": props.rowData["emp personal email"],
          "emp work phone": props.rowData["emp work phone"],
          "emp last name": props.rowData["emp last name"],
          // "emp end date": props.rowData["emp end date"],
          "emp end date": end,
          "emp first name": props.rowData["emp first name"],
          "emp personal phone": props.rowData["emp personal phone"],
          "emp id": props.rowData["emp id"]
      })

      await axios.post('https://lepc4h05p3.execute-api.us-east-1.amazonaws.com/dev', newData, {
          headers : {
              "Content-Type": "application/json",
              "Accept": "application/json"
          }
      })
      .then(res => {
          // console.log(res.data);
          alert('Contract added to employee.');
      })
      .catch((err) => {
          console.log(err);
          alert('There was an error.');
      })

      window.location.reload(true);
    // console.log("new, ", newData["employee id"])
  }

  if(modal) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }

  return (
    <>
      <div onClick={toggleModal}>
        {/* Contract ID : {props.index["contract id"] }, Contract Name: { props.index["contract name"]} */}
        Contract ID : {props.index !== undefined && props.index["contract id"]}, Contract Name : {props.index !== undefined && props.index["contract name"]}
        
      </div>

      {modal && (
        <div style = {{overflow: 'hidden'}}>
          <div onClick={toggleModal}></div>
          <div className="modal-content" >
          <div className="ui form success">
            <div className = "two fields">
              <div className = "field">
                <label htmlFor="start">Start:</label>
                  <input
                    type="date"
                    id="start"
                    style={{ width:"120px" }}></input>
              </div>
            
              <div className = "field">
                <label htmlFor="end">End:</label>
                  <input
                    type="date"
                    id="end"  
                    style={{ width:"120px" }}></input>
              </div>
            </div>
            </div>

            
            {/* <Button secondary compact size = "mini" className="close-modal" onClick={toggleModal}>
              CLOSE
            </Button>

            <Button primary compact onClick = {submit}>
              Submit
            </Button> */}

            <Button.Group className= "close-modal">
              <Button icon='check' onClick = {submit}/>
              <Button icon='x' onClick = {toggleModal} />
            </Button.Group>
          </div>
        </div>
      )}
    </>
  );
}